package com.challenge.dao;

import java.time.LocalDateTime;

public class CashDonation {
	private LocalDateTime donationDate;

    public CashDonation(String donorName, double amount, LocalDateTime donationDate) {
        super();
        this.donationDate = donationDate;
    }

    public LocalDateTime getDonationDate() {
        return donationDate;
    }

    public void setDonationDate(LocalDateTime donationDate) {
        this.donationDate = donationDate;
    }

    public void recordDonation() {
        System.out.println("Cash donation recorded on " + donationDate + " by " + getDonorName() + " of amount $" + getAmount());
    }

	private String getAmount() {
		// TODO Auto-generated method stub
		return null;
	}

	private String getDonorName() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
