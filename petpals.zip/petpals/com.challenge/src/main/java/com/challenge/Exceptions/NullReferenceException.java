package com.challenge.Exceptions;

public class NullReferenceException extends Exception{
	  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NullReferenceException(String message) {
	        super();
	    }

}
