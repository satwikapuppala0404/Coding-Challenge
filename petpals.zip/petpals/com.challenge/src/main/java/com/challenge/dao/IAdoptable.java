package com.challenge.dao;

public interface IAdoptable {
	void adopt();

}
