package com.challenge.Exceptions;

import java.io.FileNotFoundException;

public class FileHandlingException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FileHandlingException(String message, FileNotFoundException cause) {
        super(message, cause);
    }

}
